# Package initialization for locales
