# Package initialization for games
